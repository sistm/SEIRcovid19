# ============================== MODEL BUILDING MANAGEMENT ============================= #
# Building model -------------------------------------------------------------- #
#' [Monolix] Get model building settings
#' 
#' Get the settings that will be used during the run of model building. 
#' 
#' @return The list of settings
#' \itemize{
#' \item covariates: (\emph{vector<string>}) covariate names
#' \item parameters: (\emph{vector<string>}) parameters names
#' \item strategy: (\emph{string}) strategy to search best model ([cossac], samba, scm)
#' \item criterion: (\emph{string}) crtierion to search best model ([BIC], LRT)
#' \item relationships: (\emph{data.frame<parameters, covariates, locked>}) Use to lock relationships between parameters and covariates.
#' By default, all the combinations are possible. This parameter forces the use or not of some combinations.
#' See example where \emph{ka} must have \emph{SEX} and \emph{V} must not have \emph{WEIGHT}
#' \item threshold$lrt: threshold used by criterion LRT to continue or not to improve the model (first element is for forward and the second one is for the backward method)
#' \item threshold$correlation: threshold used by cossac to choose what combinations (parameter- covariate) must be tried as next candidate model (first element is for forward and the second one is for the backward method)
#' \item useLin: (\emph{boolean}) computes linearization ([TRUE]) or the Importance Sampling (FALSE)
#' \item useSAMBABeforeCossac: (\emph{boolean}) gives the possibility to launch one SAMBA iteration before the COSSAC strategy (TRUE, [FALSE]) 
#' }
#' @examples
#' \dontrun{
#' set = getModelBuildingSettings()
#' set$relationships[1,] = c("ka", "SEX", TRUE)
#' set$relationships[2,] = c("V", "WEIGHT", FALSE)
#' 
#' -> set$relationships
#'   parameters covariates locked
#' 1         ka        SEX   TRUE
#' 2          V     WEIGHT  FALSE
#' 
#' runModelBuilding(settings = set) 
#' }
#' @seealso \code{\link{runModelBuilding}}
#' @export
getModelBuildingSettings = function(){
  arguments = list()
  output = .processRequest("monolix", "getmodelbuildinginitialization", arguments, "asynchronous")
  
  #merge of parameters
  output$parameters = c(output$parameters, output$novarparameters)
  output$parameters = unlist(output$parameters)
  output$novarparameters = NULL
  
  output$relationships = as.data.frame(output$relationships, stringsAsFactors = FALSE)
  output$relationships = output$relationships[c("parameters", "covariates", "locked")]
  
  return(output)
}

#' [Monolix] Get the results of the model building
#'
#' Get the results (detailled models) of the model building 
#' 
#' @return The results of model building
#' All the detailed tried models are returned
#' \itemize{
#' \item LL: result of -2*Log-Likelihood
#' \item BICc: modified BIC.
#' \item individualModels:  (\emph{data.frame}) individual model for each individual parameter. 
#' The columns are the covariates and the elements of the data.frame notes if a covariate is used or not for the current parameter.
#' }
#' COSSAC send 2 additional fields:
#' \itemize{
#' \item tested: (\emph{vector<string>}) first element is the individual parameter and the second one is the covariate. 
#' This combination notes if the covariate is tested or not with respect to the previous model.
#' \item bestModel (\emph{boolean}) best model amongst all the tried models according to the chosen criterion.
#' }
#' SAMBA send the error model and covariance model information if there are exist
#' \itemize{
#' \item errorModels: chosen type for each error model
#' \item covarianceModels: chosen correlations between individual parameters
#' }
#' @examples
#' \dontrun{
#' getModelBuildingResults()
#' }
#' @seealso \code{\link{runModelBuilding}}
#' @export
getModelBuildingResults = function(){
  arguments = list()
  output = .processRequest(.software(), "getmodelbuildinghistory", arguments, "asynchronous")
  
  if (length(output) <= 0){
    .error("No result found for model building.")
    return(invisible(FALSE)) 
  }
  
  isCossac = !is.null(output[[1]]$tested)
  for (i in 1:length(output)){
    #rename BIC
    bicOffset = which(names(output[[i]]) == "BIC")
    names(output[[i]])[bicOffset] = "BICc"
    
    #error models (SAMBA)
    if (!is.null(output[[i]]$errorModels)){
      errorSize = length(output[[i]]$errorModels)
      d = data.frame()
      for (j in 1:errorSize){
        obsName = names(output[[i]]$errorModels)[j]
        type = names(output[[i]]$errorModels[[obsName]])[1]
        d = rbind(d, c(obsName, type))
      }
      colnames(d) = c("Model", "Type")
      output[[i]]$errorModels = d
    }
    
    #individual models (SAMBA)
    if (!is.null(output[[i]]$individualModels)){
      n = names(output[[i]]$individualModels)
      d = data.frame()
      for (j in 1:length(n)){
        covNames = names(output[[i]]$individualModels[[j]][[1]]$covariates)
        d = rbind(d, as.data.frame(output[[i]]$individualModels[[j]][[1]]$covariates))
        row.names(d)[j] = n[j]
      }
      output[[i]]$individualModels = d
    }
    
    #COSSAC - SCM
    if (!is.null(output[[i]]$tested)){
      #individual model
      n = names(output[[i]]$model)
      d = data.frame()
      for (j in 1:length(n)){
        d = rbind(d, as.data.frame(as.list(output[[i]]$model[[j]])))
        row.names(d)[j] = n[j]
      }
      output[[i]]$individualModels = d
      output[[i]]$model = NULL
    }
  }
  
  if (isCossac){
    #best model
    accepted = sapply(output, function(x)  x$accepted )
    last = which(accepted == TRUE)
    last = tail(last, n = 1)
    for (i in 1:length(output)){
      output[[i]]$accepted = NULL
      output[[i]]$bestModel = (i == last)
    }
  }else{
    for (i in 1:length(output)){
      output[[i]]$covariates = NULL
      output[[i]]$parameters = NULL
    }
  }
  
  return(output)
}

# Running model building --------------------------------------------------------------- #
#' [Monolix] Run model building 
#'
#' Run model building. 
#' Call 
#' \enumerate{
#' \item \code{\link{isRunning}} to check if the building is still running and get information about the current task,
#' \item \code{\link{stopModelBuilding}} to stop the execution.
#' }
#' 
#' To change the initialization before a run, use \code{\link{getModelBuildingSettings}} to receive all the settings. See example.
#' 
#' To launch the function in the background, so that functions which do not modify the project ("get" functions for example) remains available, set the input argument "wait" to FALSE.
#' @param wait (\emph{bool}) Should R wait for run completion before giving back the hand to the user. Equals TRUE by default.
#' @param ... (\emph{list<settings>}) Settings to initialize the model buildign algorithm. See \code{\link{getModelBuildingSettings}}.
#' @examples
#' \dontrun{
#' runModelBuilding() # sequential run
#' set = getModelBuildingSettings()
#' runModelBuilding(settings = set) # sequential run
#' runModelBuilding(wait = TRUE) # background run
#' }
#' @seealso \code{\link{getModelBuildingSettings}} \code{\link{getModelBuildingResults}} \code{\link{stopModelBuilding}} \code{\link{isRunning}}
#' @export
runModelBuilding = function(wait = TRUE, ...){
  
  arguments = list(...)
  name = names(arguments)
  
  if (!is.logical(wait)){
    .error("Unexpected type encountered for \"wait\" field. Please give a boolean.")
    return(invisible(FALSE))
  }
  
  offset = grep("settings", name)
  if (length(offset) != 0){
    inputs = arguments[[offset]]
    
    settings = list()
    inputNames = names(inputs)
    
    for (i in 1:length(inputs)){
      settings[[inputNames[i]]] = inputs[[i]]
    }
    
    if (!is.null(settings$useLin) && !is.logical(settings$useLin)){
      .error("Unexpected type encountered for \"useLin\" field. Please give a boolean.")
      return(invisible(FALSE))
    }
    
    if (!is.null(settings$useSambaBeforeCossac) && !is.logical(settings$useSambaBeforeCossac)){
      .error("Unexpected type encountered for \"useSambaBeforeCossac\" field. Please give a boolean.")
      return(invisible(FALSE))
    }
    
    if (!is.null(settings$threshold) && !is.null(settings$threshold$correlation)){
      if (!is.numeric(settings$threshold$correlation) || length(settings$threshold$correlation) != 2){
        .error("Unexpected type encountered for \"correlation\" field. Please give 2 numeric values")
        return(invisible(FALSE))
      }
      
      if (settings$threshold$correlation <= 0 || settings$threshold$correlation >= 1){
        .error("Unexpected value(s) encountered for \"correlation\" field. Please give 2 numeric values stricly between 0 and 1.")
        return(invisible(FALSE))
      }
    }
    
    if (!is.null(settings$threshold) && !is.null(settings$threshold$lrt)){
      if (!is.numeric(settings$threshold$lrt) || length(settings$threshold$lrt) != 2){
        .error("Unexpected type encountered for \"lrt\" field. Please give 2 numeric values")
        return(invisible(FALSE))
      }
      
      if (settings$threshold$lrt <= 0 || settings$threshold$lrt >= 1){
        .error("Unexpected value(s) encountered for \"lrt\" field. Please give 2 numeric values stricly between 0 and 1.")
        return(invisible(FALSE))
      }
    }
  }else{
    settings = getModelBuildingSettings()
  }
  
  output = .processRequest(.software(), "runmodelbuilding", settings, "synchronous", wait = wait, type = "STATUS")
  return(invisible(output))
}

#' [Monolix] Stop the model building
#'
#' Stop the model building.
#' @examples
#' \dontrun{
#' stopModelBuilding()
#' }
#' @seealso \code{\link{runModelBuilding}} \code{\link{isRunning}}
#' @export
stopModelBuilding = function(){
  arguments = list()
  output = .processRequest(.software(), "stopcovariateselection", arguments, "asynchronous", type = "STATUS")
  return(invisible(output))
}