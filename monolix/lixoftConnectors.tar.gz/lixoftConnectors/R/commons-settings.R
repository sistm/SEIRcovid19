# ============================== SETTINGS MANAGEMENT ============================= #
# Project Settings --------------------------------------------------------------- #
#' [Monolix - PKanalix] Set project settings
#'
#' Set the value of one or several of the settings of the project. Associated settings are:
#' \tabular{lll}{
#' "directory" \tab (\emph{string}) \tab Path to the folder where simulation results will be saved. It should be a  writable directory.\cr
#' "exportResults" \tab (\emph{bool}) \tab Should results be exported.\cr
#' "seed" \tab (\emph{0< int <2147483647}) Seed used by random generators.\cr
#' "grid" \tab (\emph{int}) Number of points for the continuous simulation grid.\cr
#' "nbSimulations" \tab (\emph{int}) Simulation number.\cr
#' "dataAndModelNextToProject" \tab (\emph{bool}) Should data and model files be saved next to project.\cr
#' }
#' @param ... A collection of comma-separated pairs \{settingName = settingValue\}.
#' @examples
#' \dontrun{
#' setProjectSettings(directory = "/path/to/export/directory", seed = 12345)
#' }
#' @seealso \code{\link{getProjectSettings}}
#' @export
setProjectSettings = function(...){

  arguments = list(...)

  arg <- .formatSetSettingsArguments(arguments)
  settingNames <- arg$settingNames;
  arguments <- arg$arguments
  if (!arg$ok) return(invisible())


  if (length(settingNames) > 0){

    for (i in 1:length(settingNames)){
      if (!.checkProjectSettingType(settingNames[i],arguments[[settingNames[i]]]))
        return(invisible(FALSE))
    }
    output = .processRequest(.software(), "setprojectsettings", arguments, "synchronous", type = "STATUS")
    return(invisible(output))

  } else
    return(invisible(TRUE))

}

#' [Monolix - PKanalix] Get project settings
#'
#' Get a summary of the project settings. Associated settings are:
#' \tabular{lll}{
#' "directory" \tab (\emph{string}) \tab Path to the folder where simulation results will be saved. It should be a writable directory.\cr
#' "exportResults" \tab (\emph{bool}) \tab Should results be exported.\cr
#' "seed" \tab (\emph{0< int <2147483647}) Seed used by random generators.\cr
#' "grid" \tab (\emph{int}) Number of points for the continuous simulation grid.\cr
#' "nbSimulations" \tab (\emph{int}) Simulation number.\cr
#' "dataAndModelNextToProject" \tab (\emph{bool}) Should data and model files be saved next to project.\cr
#' }
#' @param ... [optional] (string) Name of the settings whose value should be displayed. If no argument is provided, all the settings are returned.
#' @return An array which associates each setting name to its current value.
#' @examples
#' \dontrun{
#' getProjectSettings() # retrieve a list of all the project settings
#' 
#' getProjectSettings("directory","seed") 
#' # retrieve only the directopry and the seed settings values
#' }
#' @seealso \code{\link{getProjectSettings}}
#' @export
getProjectSettings = function(...){

  arguments = list(...)

  if(!.checkGetSettingsArguments(arguments, "settings")) return(invisible())

  output = .processRequest(.software(), "getprojectsettings", arguments, "asynchronous")
  if (!is.null(output))
    output <- .evalNumericalSettings(as.list(output))
  
  return(output)

}

.checkProjectSettingType = function(settingName, settingValue){

  isValid = TRUE
  settingName = tolower(settingName)

  if (settingName == "directory"){
    if (is.character(settingValue) == FALSE){
      .error("Unexpected type encountered. Please give a string corresponding to the path to the wanted export directory.")
      isValid = FALSE
    }
  }
  else if (settingName == "exportresults"){
    if (is.logical(settingValue) == FALSE){
      .error("Unexpected type encountered. Please give a boolean equaling TRUE if results data should be exported and FALSE if not.")
      isValid = FALSE
    }
  }
  else if (settingName == "seed"){
    if (.isInteger(settingValue) == FALSE){
      .error("Unexpected type encountered. Please give a strictly positive integer lower or equal to 2147483646.")
      isValid = FALSE
    }
  }
  else if (settingName == "grid"){
    if (.isInteger(settingValue) == FALSE){
      .error("Unexpected type encountered. Please give a strictly positive integer.")
      isValid = FALSE
    }
  }
  else if (settingName == "nbsimulations"){
    if (.isInteger(settingValue) == FALSE){
      .error("Unexpected type encountered. Please give a strictly positive integer.")
      isValid = FALSE
    }
  }
  else if (settingName == "dataandmodelnexttoproject"){
    if (is.logical(settingValue) == FALSE){
      .error("Unexpected type encountered. Please give a boolean.")
      isValid = FALSE
    }
  }
  else {
    .error(paste0("\"",settingName,"\" is not a valid setting name."))
    isValid = FALSE
  }

  return(invisible(isValid))

}
# -------------------------------------------------------------------------------- #

# Preferences -------------------------------------------------------------------- #
#' [Monolix - PKanalix] Set preferences
#'
#' Set the value of one or several of the project preferences. Prefenreces are:
#' \tabular{lll}{
#' "relativePath" \tab (\emph{bool}) \tab Use relative path for save/load operations.\cr
#' "threads" \tab (\emph{int >0}) \tab Number of threads.\cr
#' "timeStamping" \tab (\emph{bool}) Create an archive containing result files after each run.\cr
#' "dpi" \tab (\emph{bool}) Apply high density pixel correction.\cr
#' "imageFormat" \tab (\emph{string}) Image format used to save monolix graphics.\cr
#' "delimiter" \tab (\emph{string}) Character use as delimiter in exported result files.\cr
#' "exportCharts" \tab (\emph{bool}) Should graphics images be exported.\cr
#' "exportChartsData" \tab (\emph{bool}) Should graphics data be exported.\cr
#' "headerAliases" \tab (\emph{list("header" = vector<string>)}) For each header, the list of the recognized aliases.\cr
#' }
#' @param ... A collection of comma-separated pairs \{preferenceName = settingValue\}.
#' @examples
#' \dontrun{
#' setPreferences(exportCharts = FALSE, delimiter = ",")
#' }
#' @seealso \code{\link{getPreferences}}
#' @export
setPreferences = function(...){

  arguments = list(...)

  arg <- .formatSetSettingsArguments(arguments, settingsType = "preference")
  settingNames <- arg$settingNames; arguments <- arg$arguments
  if(! arg$ok) return(invisible())

  if (length(settingNames) > 0){
    for (i in 1:length(settingNames)){
      if (.checkPreferenceType(settingNames[i],arguments[[settingNames[i]]]) == FALSE){
        return(invisible(FALSE))
      }
    }
    output = .processRequest(.software(), "setpreferences", arguments, "synchronous", type = "STATUS")
    return(invisible(output))
  }
  else {
    return(invisible(TRUE))
  }

}

#' [Monolix - PKanalix] Get project preferences
#'
#' Get a summary of the project preferences. Preferences are:
#' \tabular{lll}{
#' "relativePath" \tab (\emph{bool}) \tab Use relative path for save/load operations.\cr
#' "threads" \tab (\emph{int >0}) \tab Number of threads.\cr
#' "timeStamping" \tab (\emph{bool}) Create an archive containing result files after each run.\cr
#' "dpi" \tab (\emph{bool}) Apply high density pixel correction.\cr
#' "imageFormat" \tab (\emph{string}) Image format used to save monolix graphics.\cr
#' "delimiter" \tab (\emph{string}) Character use as delimiter in exported result files.\cr
#' "exportCharts" \tab (\emph{bool}) Should graphics images be exported.\cr
#' "exportChartsData" \tab (\emph{bool}) Should graphics data be exported.\cr
#' "headerAliases" \tab (\emph{list("header" = vector<string>)}) For each header, the list of the recognized aliases.\cr
#' }
#' @param ... [optional] (string) Name of the preference whose value should be displayed. If no argument is provided, all the preferences are returned.
#' @return An array which associates each preference name to its current value.
#' @examples
#' \dontrun{
#' getPreferences() # retrieve a list of all the general settings
#' 
#' getPreferences("imageFormat","exportCharts") 
#' # retrieve only the imageFormat and exportCharts settings values
#' }
#' @seealso \code{\link{setGeneralSettings}}
#' @export
getPreferences = function(...){

  arguments = list(...)

  if(!.checkGetSettingsArguments(arguments, "preference")) return(invisible())

  output = .processRequest(.software(), "getpreferences", arguments, "asynchronous")
  if (!is.null(output))
    output <- .evalNumericalSettings(as.list(output))
  
  return(output)

}

.checkPreferenceType = function(settingName, settingValue){

  isValid = TRUE
  settingName = tolower(settingName)
  
  if (settingName == "relativepath"){
    if (is.logical(settingValue) == FALSE){
      .error("Unexpected type encountered. \"relativePath\" must be a boolean.")
      isValid = FALSE
    }
  }
  else if (settingName == "threads" ){
    if (.isInteger(settingValue) == FALSE){
      .error("Unexpected type encountered. \"threads\" must be a strictly positive integer.")
      isValid = FALSE
    }
  }
  else if (settingName == "timestamping"){
    if (is.logical(settingValue) == FALSE){
      .error("Unexpected type encountered. \"timestamping\" must be a boolean.")
      isValid = FALSE
    }
  }
  else if (settingName == "dpi"){
    if (is.logical(settingValue) == FALSE){
      .error("Unexpected type encountered. \"dpi\" must be a boolean.")
      isValid = FALSE
    }
  }
  else if (settingName == "imageformat"){
    if (is.character(settingValue) == FALSE){
      .error("Unexpected type encountered. \"imageformat\" must be a string.")
      isValid = FALSE
    }
  }
  else if (settingName == "delimiter"){
    if (is.character(settingValue) == FALSE){
      .error("Unexpected type encountered. \"delimiter\" must be a string.")
      isValid = FALSE
    }
  }
  else if (settingName == "exportcharts"){
    if (is.logical(settingValue) == FALSE){
      .error("Unexpected type encountered. \"exportCharts\" must be a boolean.")
      isValid = FALSE
    }
  }
  else if (settingName == "exportchartsdata"){
    if (is.logical(settingValue) == FALSE){
      .error("Unexpected type encountered. \"exportchartsdata\" must be a boolean.")
      isValid = FALSE
    }
  }
  else if (settingName == "headeraliases"){
    if (is.list(settingValue) == FALSE)
      isValid = FALSE
    else if (length(settingValue)){
      for (i in 1:length(settingValue)){
        if (!is.character(settingValue[[i]])){
          isValid = FALSE
          break
        }
      }
    }
    
    if (!isValid)
      .error("Unexpected type encountered. \"headeraliases\" must be a list of string vectors.")
  }
  else {
    .error(paste0("\"",settingName,"\" is not a valid preference name."))
    isValid = FALSE
  }

  return(invisible(isValid))

}
# -------------------------------------------------------------------------------- #

# Helpers ------------------------------------------------------------------------ #
.evalNumericalSettings = function(settingList){

  return( lapply(settingList, function(x) .evalNumerics(x)) )

}

.checkGetSettingsArguments <- function(arguments, settingsType){

  return(.checkArguments(arguments, paste0("valid ", settingsType)))

}

.formatSetSettingsArguments <- function(arguments, settingsType = "setting"){

  if (is.null(names(arguments)) && length(arguments) == 1)
    arguments <- arguments[[1]]
  settingNames = names(arguments)
  ok <- TRUE

  if ( length(settingNames) != length(arguments) ){
    .error(paste0("Unvalid input format. Please give a list of comma-separated pairs {", settingsType, "Name = ", settingsType, "Value}."))
    ok <-FALSE
  }

  return(list(arguments = arguments, settingNames = settingNames, ok = ok))

}
# -------------------------------------------------------------------------------- #
# ================================================================================ #
