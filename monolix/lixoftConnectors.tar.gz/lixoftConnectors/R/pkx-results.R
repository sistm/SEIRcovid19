# ===================================== RESULTS ================================== #
# Algorithms Output -------------------------------------------------------------- #
#' [PKanalix] Get NCA individual parameters
#'
#' Get the estimated values for each subject of some of the individual NCA parameters of the current project.
#' @param ... (\emph{string}) Name of the individual parameters whose values must be displayed.
#' @return A data frame giving the estimated values of the individual parameters of interest for each subject,
#' and a list of their associated statistics.
#' @examples
#' \dontrun{
#' indivParams = getNCAIndividualParameters() 
#' # retrieve the values of all the available parameters.
#' 
#' indivParams = getNCAIndividualParameters("Tmax","Clast") 
#' # retrieve only the values of Tmax and Clast for all individuals.
#'
#'   $parameters->
#'       id  Tmax Clast
#'       1   0.8  1.2
#'       .   ...  ...
#'       N   0.4  2.2
#'
#'       }
#' @export
getNCAIndividualParameters <- function(...){
  
  arguments = list(...)
  if (!.checkParametersArguments(arguments, "individual"))
    return(invisible())
  
  if (length(arguments) == 1)
    arguments <- as.list(arguments[[1]])
  
  output = .processRequest("pkanalix", "getncaresults", arguments, "asynchronous")
  return(.formatPKanalixResults(output))
  
}

#' [PKanalix] Get CA individual parameters
#'
#' Get the estimated values for each subject of some of the individual CA parameters of the current project.
#' @param ... (\emph{string}) Name of the individual parameters whose values must be displayed.
#' @return A data frame giving the estimated values of the individual parameters of interest for each subject,
#' and a list of their associated statistics.
#' @examples
#' \dontrun{
#' indivParams = getCAIndividualParameters() # retrieve all the available individual parameters values.
#' indivParams = getCAIndividualParameters("ka", "V") # retrieve ka and V values for all individuals.
#'
#'   $parameters->
#'       id  ka    V
#'       1   0.8  1.2
#'       .   ...  ...
#'       N   0.4  2.2
#'
#'       }
#' @export
getCAIndividualParameters <- function(...){

  arguments = list(...)
  if (!.checkParametersArguments(arguments, "individual"))
    return(invisible())

  if (length(arguments) == 1)
    arguments <- as.list(arguments[[1]])

  output = .processRequest("pkanalix", "getcaresults", arguments, "asynchronous")
  return(.formatPKanalixResults(output))

}
# -------------------------------------------------------------------------------- #

.formatPKanalixResults <- function(output){

  if (length(output$individualEstimates$parameterValues) == 0)
    return(NULL)


  meaningfulStatistics <- output$statistics$columns

  result <- list(output$individualEstimates$ids$id)
  parameterNames <- NULL
  statistics <- NULL

  for (iParam in (1:length(output$individualEstimates$parameterValues))){

    index <- output$individualEstimates$parameterNames[[iParam]]$value
    result <- c(result, list(as.numeric(output$individualEstimates$parameterValues[[index + 1]])))
    parameterNames <- c(parameterNames, output$individualEstimates$parameterNames[[iParam]]$key)

    
    statByParam <- list()

    for (iStat in (1:length(meaningfulStatistics))){
      for (iCol in (1:length(meaningfulStatistics[[iStat]]$label))){
        value <- output$statistics$table[[iParam]]$value[[ meaningfulStatistics[[iStat]]$key ]][[iCol]]
        statByParam[[ meaningfulStatistics[[iStat]]$label[[iCol]] ]] <- if (!is.null(value)) value else NaN
      }
    }

    statistics <- rbind(statistics, statByParam)

  }

  ## covariates
  staticsNames <- parameterNames
  if(length(output$individualEstimates$covariates)){
    for (iParam in (1:length(output$individualEstimates$covariates))){
      result <- c(result, list(output$individualEstimates$covariates[[iParam]]))
      parameterNames <- c(parameterNames, names(output$individualEstimates$covariates)[iParam])
    }
  }
  
  names(result) <- c("ID", parameterNames)
  result <- as.data.frame(result)
  rownames(statistics) <- staticsNames
  statistics <- as.data.frame(statistics)

  output <- list(parameters = result, statistics = statistics)
  return(output)

}
# ================================================================================ #
