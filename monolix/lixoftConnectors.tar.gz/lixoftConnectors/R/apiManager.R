#' Get lixoftConnectors API current state
#' 
#' Retrieve information about the Lixoft software the lixoftConnectors are currently interfacing with.
#' @param quietly \emph{boolean} If TRUE, no warning is raised when lixoftConnectors package is not initialized. Equals FALSE by default.
#' @return A structure containing:
#' \itemize{
#'   \item \code{path}: path to Lixoft installation directory
#'   \item \code{software}: software name
#'   \item \code{version}: Lixoft softwares suite version
#' }
#' @export
getLixoftConnectorsState <- function(quietly = FALSE){
  
  output = list()
  output$software <- .software()
  
  if (output$software == "mlxlibrary")
    output$software <- "simulx"
  else if (output$software == ""){
    if (!quietly)
      .warning("lixoftConnectors package has not been initialized yet.")
    return(NULL)
  }
  
  output$path = get("LIXOFT_DIRECTORY", envir = LixoftEnvironment)
  output$version = .processRequest(.software(), "getlixoftsuiteversion", list(), "asynchronous")
  
  return(output)
  
}


#' Initialize lixoftConnectors API
#' 
#' Initialize lixoftConnectors API for a given software
#' @param software (\emph{character}) [optional] Name of the software to be loaded. By default, "monolix" software is used.\cr
#' @param path (\emph{character}) [optional] Path to installation directory of the Lixoft suite.
#' If lixoftConnectors library is not already loaded and no path is given, the directory written in the lixoft.ini file is used for initialization.
#' @param force (\emph{bool}) [optional] Should software switch security be overpassed or not. Equals FALSE by default.
#' @return A boolean equaling TRUE if the initialization has been successful and FALSE if not.
#' @examples
#' \dontrun{
#' initializeLixoftConnectors(software = "monolix", path = "/path/to/lixoftRuntime/")
#' }
#' @export
initializeLixoftConnectors <- function(software = "monolix", path = "", force = FALSE) {
  
  if (!is.character(software)){
    .error("Unexpected type encountered for the \"software\" field. Please give a string corresponding to the name of the Lixoft software to be used.")
    return(invisible(FALSE))
  }
  if (!is.character(path)){
    .error("Unexpected type encountered for the \"path\" field. Please give a string corresponding to the path to the Lixoft Suite installation directory.")
    return(invisible(FALSE))
  }
  
  
  # check if the lixoftConnectors library is already loaded:
  lixoftLibraryInfo <- .getLixoftLibraryInformation()
  loadedDLLs <- getLoadedDLLs()
  currentLoadedLibPath <- loadedDLLs[[lixoftLibraryInfo$name]]
  currentSoftware <- .software()
  
  if (!is.null(currentLoadedLibPath)){
    
    testedLibPath = file.path( normalizePath(path, winslash = "/", mustWork = FALSE), "lib", paste0(lixoftLibraryInfo$name, lixoftLibraryInfo$suffix, collapse = "") )
    
    
    if (path == "" || currentLoadedLibPath[["path"]] == testedLibPath) {
      
      if (currentSoftware == "mlxlibrary")
        currentSoftware <- "simulx"
      
      if (software == currentSoftware){
        
        .info(paste0("The library ", get("LIXOFT_CONNECTORS_LIB_NAME", envir = LixoftEnvironment), " (\"",
                     get("LIXOFT_CONNECTORS_LIB_PATH", envir = LixoftEnvironment), "\") is already loaded and initialized for ",
                     software, " software -> nothing to be done."));
        return(invisible(TRUE));
        
      } else if (currentSoftware != "simulx" && !force && !getOption("lixoft_lixoftConnectors_forceSoftwareSwitch")){
          
        .info(paste0("lixoftConnectors package is about to switch from \"", currentSoftware, "\" mode to \"", software, "\" mode.\n",
                     "Information relative to the previous \"", currentSoftware, "\" session won't be accessible anymore ",
                     "and potential unsaved project changes and associated results will be lost."))
        
        ans <- readline("Proceed software switch ? [y|N] ")
        
        if (!is.character(ans) || (tolower(ans) != "yes" && tolower(ans) != "y"))
          return(invisible(FALSE))
          
      }
       
        
      status = .initializeLixoftSession(software)
      if (status)
        .info(paste0("lixoftConnectors package switched from \"", currentSoftware, "\" mode to \"", software, "\" mode."))
      
      return(invisible(status))
      
    } else {
      
      .warning(paste0("lixoftConnectors package has already been initialized with \"", get("LIXOFT_DIRECTORY", envir = LixoftEnvironment),
                      "\". R session must be restarted to use a different Lixoft installation directory."))
      return(invisible(FALSE))
      
    }
    
  }
  
  
  # set environment:
  status = .setLixoftDirectory(software, path)
  if (!status) return(invisible(FALSE))
  
  Sys.setenv( LIXOFT_HOME = get("LIXOFT_DIRECTORY", envir = LixoftEnvironment))
  
  OS = .getOS()
  if (OS == "Windows") {
    runtimeDir = gsub("/", "\\\\", get("LIXOFT_DIRECTORY", envir = LixoftEnvironment))
    Sys.setenv(PATH = paste0( runtimeDir,"\\tools\\MinGW\\bin;",
                              runtimeDir,"\\...\\tools\\MinGW\\bin;",
                              get("SYSTEM_PATH", envir = LixoftEnvironment) ) )
  }
  
  
  # load library :
  PATH <- Sys.getenv(if (OS == "Windows") "PATH" else "LD_LIBRARY_PATH")
  
  if (OS == "Unix") {
    Sys.setenv( LD_LIBRARY_PATH = paste0( dirname(get("LIXOFT_CONNECTORS_LIB_PATH", envir = LixoftEnvironment)), ":", PATH), collapse = "" )
  } else if (OS == "Apple") {
    # path is set during installation
  } else if (OS == "Windows") {
    Sys.setenv(PATH = paste0( gsub("/", "\\\\", dirname(get("LIXOFT_CONNECTORS_LIB_PATH", envir = LixoftEnvironment))), ";", PATH) )
  }
  
  lixoftDll = dyn.load(get("LIXOFT_CONNECTORS_LIB_PATH", envir = LixoftEnvironment))
  .dynLibs(c(.dynLibs(), list(lixoftDll)))
  
  if (OS == "Unix")
    Sys.setenv(LD_LIBRARY_PATH = PATH)
  else if (OS == "Windows")
    Sys.setenv(PATH = PATH)
  
  
  # initialize session:
  status = .initializeLixoftSession(software)
  if (status)
    .info(paste0("The lixoftConnectors package has been successfully initialized:\nlixoftConnectors package version -> ",
                 packageVersion("lixoftConnectors"), "\nLixoft softwares suite version   -> ", getLixoftConnectorsState()$version))
  
  return(invisible(status))
  
}

.setLixoftDirectory <- function(software, path = ""){
  
  # identify default lixoft directory:
  
  .getDefaultDirectory <-function()
  {
    OS = .getOS()
    if (OS == "Unix") {
      lixoftIniPath <- paste0(Sys.getenv("HOME"), "/lixoft/lixoft.ini")
    } else if (OS == "Apple") {
      lixoftIniPath <- paste0(Sys.getenv("HOME"), "/lixoft/lixoft.ini")
    } else if (OS == "Windows") {
      lixoftIniPath <- paste0(Sys.getenv("HOMEDRIVE"), Sys.getenv("HOMEPATH"), "\\lixoft\\lixoft.ini")
    } else {
      .error("Unknown OS.")
      return(invisible(FALSE))
    }
    return(lixoftIniPath)
  }
    
  if (path == ""){
    
    lixoftIniPath <- .getDefaultDirectory()
    
    path = .getLixoftDirectoryFromInitializationFile(lixoftIniPath)
    if (path == "")
      return(invisible(FALSE))
    
    .info(paste0("The directory specified in the initialization file of the Lixoft Suite (located at \"", lixoftIniPath,
                 "\") will be used by default: \"", path, "\""))
    
  }
  
  
  # check lixoft directory and lixoftConnectors library existence:
  path = normalizePath(path, winslash = "/", mustWork = FALSE)
  
  if (!.exists(path)) {
    .error(paste0("The directory \"", path, "\" does not exist."))
    return(invisible(FALSE))
  }
  
  lixoftLibraryInfo = .getLixoftLibraryInformation()
  lixoftConnectorsLibPath <- file.path(path, "lib", paste0(lixoftLibraryInfo$name, lixoftLibraryInfo$suffix, collapse = ""))
  if (!.exists(lixoftConnectorsLibPath)){
    .error(paste0("Impossible to find the needed library \"", lixoftConnectorsLibPath,
                  "\".\nPlease note that lixoftConnectors package is not compatible with LixoftSuite versions older than 2019R1."))
    return(invisible(FALSE))
  }
  
  assign("LIXOFT_DIRECTORY", path, envir = LixoftEnvironment)
  assign("LIXOFT_CONNECTORS_LIB_NAME", lixoftLibraryInfo$name, envir = LixoftEnvironment)
  assign("LIXOFT_CONNECTORS_LIB_PATH", normalizePath(lixoftConnectorsLibPath), envir = LixoftEnvironment)
  
  # fill lixoft.ini if empty monolixSuite location   
  defaultPath = .getLixoftDirectoryFromInitializationFile(lixoftIniPath = .getDefaultDirectory(), throwError = FALSE)
  if(defaultPath == ""){
    system(paste0(path,"/lib/monolixSuiteInit --silent"))
  }
  
  return(invisible(TRUE))
  
}

.getLixoftDirectoryFromInitializationFile <- function(lixoftIniPath, software, throwError = TRUE){
  
  if (!.exists(lixoftIniPath)){
    if(throwError){
    .error(paste0("Impossible to find an initialization file for Lixoft Suite.\nSpecify it directly in initializeLixoftConnectors(path = 'pathToMonolixSuite') or launch the executable monolixSuiteInit in your pathToMonolixSuite/lib folder."))
    }
    return("")
  }
  
  readDirectory <- function(lines, key){
    
    if (length(lines) > 0){
      for (i in 1:length(lines)){
        res = regexpr(paste0("^", key, "="), lines[[i]])
        if (res != -1)
          return(substring(lines[[i]], res + attr(res, "match.length")))
      } 
    }
    return("")
    
  }
  
  
  lines = readLines(lixoftIniPath)
  
  path = readDirectory(lines, "monolixSuite") # >= 2018R1 (no connectors for anterior versions)
  if (path == "" && throwError)
    .error(paste0("Cannot find any valid default installation path for Lixoft(@) software suite in the initialization file \"",
                  lixoftIniPath, "\".\nPlease note that lixoftConnectors package is not compatible with Lixoft (@) suite versions older than 2019R1."))
  
  return(path)
  
}

.getLixoftLibraryInformation <- function(){
  
  OS = .getOS()
  if (OS == "Unix") {
    lixoftConnectorsLibName <- "liblixoftConnectors"
    libSuffix <- ".so"
  }
  else if (OS == "Apple") {
    lixoftConnectorsLibName <- "liblixoftConnectors"
    libSuffix <- ".so" # ".dylib" won't be loaded by .C()
  }
  else if (OS == "Windows") {
    lixoftConnectorsLibName <- "lixoftConnectors"
    libSuffix <- ".dll"
  }
  else {
    .error("Unknown OS.")  
    return(invisible(FALSE))
  }
  
  return(invisible( list(name = lixoftConnectorsLibName, suffix = libSuffix) ))
  
}

.initializeLixoftSession <- function(software){
  
  if (software == "simulx")
    software = "mlxlibrary"
  
  arguments = list(software = software, libpath = get("LIXOFT_CONNECTORS_LIB_PATH", envir = LixoftEnvironment))
  output = .processRequest("session", "initialize", arguments, "synchronous", type = "STATUS")
  
  if (output)
    assign("LIXOFT_SOFTWARE", software, envir = LixoftEnvironment)
  # else # unload library if initialization failed
  #   .unloadLixoftConnectorsLibrary()
  
  return(invisible(output))  
  
}

.software <- function (){
  
  softname <- get("LIXOFT_SOFTWARE", envir = LixoftEnvironment)
  return(softname)
  
}

.unloadLixoftConnectorsLibrary <- function(){
  
  output = .processRequest("session", "unload", list(void = ""), "synchronous", type = "STATUS")
  
  if (output){
    
    dyn.unload(get("LIXOFT_CONNECTORS_LIB_PATH", envir = LixoftEnvironment))
    
    assign("LIXOFT_DIRECTORY", "", envir = LixoftEnvironment)
    assign("LIXOFT_CONNECTORS_LIB_NAME", "", envir = LixoftEnvironment)
    assign("LIXOFT_CONNECTORS_LIB_PATH", "", envir = LixoftEnvironment)
    assign("LIXOFT_SOFTWARE", "", envir = LixoftEnvironment)
    
    return(TRUE)
    
  } else
    return(FALSE)
  
}

.onLoad <- function(libname, pkgname){
  
  # initialize lixoft options
  if (is.null(getOption("lixoft_lixoftConnectors_forceSoftwareSwitch")))
    options(lixoft_lixoftConnectors_forceSoftwareSwitch = FALSE)
  
  
  # set notification options:
  notificationOptions <- getOption("lixoft_notificationOptions")
  
  if (is.null(notificationOptions$errors))
    notificationOptions$errors <- 0
  if (is.null(notificationOptions$warnings))
    notificationOptions$warnings <- 0
  if (is.null(notificationOptions$info))
    notificationOptions$info <- 0
  
  options(lixoft_notificationOptions = notificationOptions)
  
  
  
  # register session cleaner
  reg.finalizer(LixoftEnvironment, function(e){ 
    
    if (isNamespaceLoaded("lixoftConnectors"))
      unloadNamespace("lixoftConnectors")
  
  }, TRUE)
  
}

.onAttach <- function(libname, pkgname){}

.onUnload <- function(libpath){
  
  #  unload lixoftConnectors library:
  loadedDLLs <- getLoadedDLLs();
  if (exists("LIXOFT_CONNECTORS_LIB_NAME", envir = LixoftEnvironment) && !is.null(loadedDLLs[[get("LIXOFT_CONNECTORS_LIB_NAME", envir = LixoftEnvironment)]]))
    .unloadLixoftConnectorsLibrary()
  
  
  # reset environment:
  Sys.setenv( LIXOFT_HOME = "")
  
  OS = .getOS()
  if (OS == "Unix") {
    Sys.setenv( LD_LIBRARY_PATH = get("SYSTEM_PATH", envir = LixoftEnvironment) )
  } else if (OS == "Apple") {
    # path is set during installation
  } else if (OS == "Windows") {
    Sys.setenv( PATH = get("SYSTEM_PATH", envir = LixoftEnvironment) )
  }
  
  
  # reset R session options:
  originalOptions = get("ORIGINAL_OPTIONS", envir = LixoftEnvironment)
  options(originalOptions)
  options(lixoft_lixoftConnectors_forceSoftwareSwitch = originalOptions$lixoft_lixoftConnectors_forceSoftwareSwitch)
  
}

.onDetach <- function(libpath){}

#' Get information about LixoftEnvironment object
#' @export
getLixoftEnvInfo <- function(){
  
  r <- list(ls.str(envir = LixoftEnvironment), parent.env(LixoftEnvironment))
  return(r)
  
}