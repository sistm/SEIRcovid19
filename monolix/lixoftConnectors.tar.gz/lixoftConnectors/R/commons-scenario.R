# ============================== SCENARIO MANAGEMENT ============================= #
# Running Scenario --------------------------------------------------------------- #
#' [Monolix - PKanalix] Stop the current task run
#'
#' Stop the current task run.
#' @examples
#' \dontrun{
#' abort()
#' }
#' @seealso \code{\link{runScenario}}
#' @export
abort = function(){

  arguments = list()
  output = .processRequest(.software(), "abort", arguments, "asynchronous", type = "STATUS")
  return(invisible(output))

}

#' [Monolix - PKanalix] Get current scenario state
#'
#' Check if a scenario is currently running. If yes, information about the current running task are displayed.
#' @param verbose (\emph{bool}) Should information about the current running task be displayed in the console or not. Equals FALSE by default.
#' @return A boolean which equals TRUE if a scenario is currently running.
#' @examples
#' \dontrun{
#' isRunning()
#' }
#' @seealso \code{\link{runScenario}} \code{\link{abort}}
#' @export
isRunning = function(verbose = FALSE){

  if (!.checkBooleanArgument(verbose, "verbose"))
    return(invisible(FALSE))

  arguments = list()
  output = .processRequest(.software(), "getworkflowstate", arguments, "asynchronous")


  tryCatch(expr = {

    if (verbose){
      if (output[[1]] == TRUE){
        .info(paste0("Currently running task :\n",output[[2]]))
      } else {
        .info("No task currently running.")
      }
    }
    return(invisible(output[[1]]))

  }, error = function(err){

    output = list()
    .error("Bad output encountered.")

  })

}

#' [Monolix - PKanalix] Get last run status
#'
#' Return an execution report about the last run with a summary of the error which could have occurred.
#' @return A structure containing
#' \enumerate{
#' \item a boolean which equals TRUE if the last run has successfully completed,
#' \item a summary of the errors which could have occurred.
#'}
#' @examples
#' \dontrun{
#' lastRunInfo = getLastRunStatus()
#' lastRunInfo$status
#'  -> TRUE
#' lastRunInfo$report
#'  -> ""
#'  }
#' @seealso \code{\link{runScenario}} \code{\link{abort}} \code{\link{isRunning}}
#' @export
getLastRunStatus = function(){

  arguments = list()
  output = .processRequest(.software(), "getlastrunstatus", arguments, "asynchronous")
  return(output)

}
# -------------------------------------------------------------------------------- #

# Helpers ------------------------------------------------------------------------ #
.checkBooleanArgument <- function(arg, name){

  if (!is.logical(arg)){
    .error("Unexpected type encountered for \"" + name + "\" field. Please give a boolean.")
    return(invisible(FALSE))
  }
  return(invisible(TRUE))

}

.checkWaitArgument <- function(wait){

  return(.checkBooleanArgument(wait, "wait"))

}
# -------------------------------------------------------------------------------- #
# ================================================================================ #
