# ============================== SETTINGS MANAGEMENT ============================= #
# Common Settings ---------------------------------------------------------------- #
#' [PKanalix] Get the global observation id used in both the compartmental and non compartmental analysis
#'
#' Get the global observation id used in both the compartmental and non compartmental analysis.
#' @return the observation id used in computations.
#' @examples
#' \dontrun{
#' getGlobalObsIdToUse() # 
#' }
#' @seealso \code{\link{setGlobalObsIdToUse}}
#' @export
getGlobalObsIdToUse <- function(){
  
  output = .processRequest("pkanalix", "getgeneralsettings", list(), "asynchronous")
  if (!is.null(output))
    output <- as.list(output)$obsidtouse
  
  return(output)
  
}

#' [PKanalix] Set the global observation id used in both the compartmental and non compartmental analysis
#'
#' Get the global observation id used in both the compartmental and non compartmental analysis.
#' @param ... ("id" \emph{string}) the observation id from data section to use for computations.\cr
#' @examples
#' \dontrun{
#' setGlobalObsIdToUse("id") # 
#' }
#' @seealso \code{\link{getGlobalObsIdToUse}}
#' @export
setGlobalObsIdToUse <- function(...){
  
  settingNames <- "obsidtouse"
  arguments = list("obsidtouse" =  (...))
 
  if (.checkPKanalixSettingType(settingNames, arguments[[1]]) == FALSE){
    return(invisible(FALSE))
  }
  
  output = .processRequest("pkanalix", "setgeneralsettings", arguments, "asynchronous", type = "STATUS")

  return(invisible(output))
  
}



# NCA Settings ------------------------------------------------------------------- #
#' [PKanalix] Get the settings associated to the non compartmental analysis
#'
#' Get the settings associated to the non compartmental analysis. Associated settings are:
#' \tabular{lll}{
#' "administrationType" \tab (\emph{list}) \tab list(key = "admId", value = \emph{string}("intravenous" or "extravascular")). \emph{admId} Admninistration ID from data set or 1 if no admId column in the dataset.\cr\cr
#' "integralMethod" \tab (\emph{string}) \tab Method for AUC and AUMC calculation and interpolation.\cr\cr
#' "partialAucTime" \tab (\emph{list}) \tab  The first element of the list is a bolean describing if this setting is used. The second element of the list is the value of the bounds of the partial AUC calculation interval.\cr\cr
#' "blqMethodBeforeTmax" \tab (\emph{string}) \tab Method by which the BLQ data before Tmax should be replaced.\cr\cr
#' "blqMethodAfterTmax" \tab (\emph{string}) \tab Method by which the BLQ data after Tmax should be replaced.\cr\cr
#' "ajdr2AcceptanceCriteria" \tab (\emph{list}) \tab The first element of the list is a boolean describing if this setting is used. The second element of the list is the value of the adjusted R2 acceptance criteria for the estimation of lambda_Z.\cr\cr
#' "extrapAucAcceptanceCriteria" \tab (\emph{list}) \tab The first element of the list is a boolean describing if this setting is used. The second element of the list is the value of the AUC extrapolation acceptance criteria for the estimation of lambda_Z.\cr\cr
#' "spanAcceptanceCriteria" \tab (\emph{list}) \tab The first element of the list is a boolean describing if this setting is used. The second element of the list is the value of the span acceptance criteria for the estimation of lambda_Z.\cr\cr
#' "lambdaRule" \tab (\emph{string}) \tab Main rule for the lambda_Z estimation.\cr\cr
#' "timeInterval" \tab (\emph{vector}) \tab Time interval for the lambda_Z estimation when "\emph{lambdaRule}" = "interval".\cr\cr
#' "timeValuesPerId" \tab (\emph{list}) \tab list("idName" = idTimes,...): \emph{idTimes} Observation times to use for the calculation of lambda_Z for the id \emph{idName}.\cr\cr
#' "nbPoints" \tab (\emph{integer}) \tab Number of points for the lambda_Z estimation when "\emph{lambdaRule}" = "points".\cr\cr
#' "maxNbOfPoints" \tab (\emph{list}) \tab The first element of the list is a boolean describing if this setting is used. The second element of the list is the value maximum number of points to use for the lambda_Z estimation when "\emph{lambdaRule}" = "R2" or "adjustedR2".\cr\cr
#' "startTimeNotBefore" \tab (\emph{list}) \tab The first element of the list is a boolean describing if this setting is used. The second element of the list is the value minimum time value to use for the lambda_Z estimation when "\emph{lambdaRule}" = "R2" or "adjustedR2".\cr\cr
#' "weightingNCA" \tab (\emph{string}) \tab Weighting method used for the regression that estimates lambda_Z. \cr\cr
#' }
#' @param ... [optional] (string) Name of the settings whose value should be displayed. If no argument is provided, all the settings are returned.
#' @return An array which associates each setting name to its current value.
#' @examples
#' \dontrun{
#' getNCASettings() # retrieve a list of all the NCA methodology settings
#' getNCASettings("lambdaRule","integralMethod") # retrieve a list containing only the value of the settings whose name has been passed in argument
#' }
#' @seealso \code{\link{setNCASettings}}
#' @export
getNCASettings <- function(...){

  arguments = list(...)
  if(!.checkGetSettingsArguments(arguments, "settings")) return(invisible())

  output = .processRequest("pkanalix", "getncasettings", arguments, "asynchronous")
  if (!is.null(output))
    output <- as.list(output)
  
  return(output)

}

#' [PKanalix] Set the value of one or several of the settings associated to the non compartmental analysis
#'
#' Set the value of one or several of the settings associated to the non compartmental analysis. Associated settings are:
#' \tabular{lll}{
#' "administrationType" \tab (\emph{list}) \tab list(key = "admId", value = \emph{string}("intravenous" or "extravascular")). \emph{admId} Admninistration ID from data set or 1 if no admId column in the dataset.\cr
#' "integralMethod" \tab (\emph{string}) \tab Method for AUC and AUMC calculation and interpolation.\cr\cr
#' "partialAucTime" \tab (\emph{list}) \tab  The first element of the list is a bolean describing if this setting is used. The second element of the list is the value of the bounds of the partial AUC calculation interval. By default, the boolean equals \strong{FALSE} and the bounds are \strong{c(-Inf, +Inf)}.\cr\cr
#' "blqMethodBeforeTmax" \tab (\emph{string}) \tab Method by which the BLQ data before Tmax should be replaced. Possible methods are "missing", "LOQ", "LOQ2" or "\strong{zero}" (default).\cr\cr
#' "blqMethodAfterTmax" \tab (\emph{string}) \tab Method by which the BLQ data after Tmax should be replaced. Possible methods are "zero", "missing", "LOQ"  or "\strong{LOQ2}" (default).\cr\cr
#' "ajdr2AcceptanceCriteria" \tab (\emph{list}) \tab The first element of the list is a boolean describing if this setting is used. The second element of the list is the value of the adjusted R2 acceptance criteria for the estimation of lambda_Z. By default, the boolean equals \strong{FALSE} and the value is \strong{0.98}.\cr\cr
#' "extrapAucAcceptanceCriteria" \tab (\emph{list}) \tab The first element of the list is a boolean describing if this setting is used. The second element of the list is the value of the AUC extrapolation acceptance criteria for the estimation of lambda_Z. By default, the boolean equals \strong{FALSE} and the value is \strong{20}.\cr\cr
#' "spanAcceptanceCriteria" \tab (\emph{list}) \tab The first element of the list is a boolean describing if this setting is used. The second element of the list is the value of the span acceptance criteria for the estimation of lambda_Z. By default, the boolean equals \strong{FALSE} and the value is \strong{3}.\cr\cr
#' "lambdaRule" \tab (\emph{string}) \tab Main rule for the lambda_Z estimation. Possible rules are "R2", "interval", "points" or "\strong{adjustedR2}" (default).\cr\cr
#' "timeInterval" \tab (\emph{vector}) \tab Time interval for the lambda_Z estimation when "\emph{lambdaRule}" = "interval". This is a vector of size two, default = \strong{c(-inf, inf)}\cr\cr
#' "timeValuesPerId" \tab (\emph{list}) \tab list("idName" = idTimes,...): \emph{idTimes} Observation times to use for the calculation of lambda_Z
#' for the id \emph{idName}. Default = \strong{NULL}, all the times values are used.\cr\cr
#' "nbPoints" \tab (\emph{integer}) \tab Number of points for the lambda_Z estimation when "\emph{lambdaRule}" = "points". Default = \strong{3}.\cr\cr
#' "maxNbOfPoints" \tab (\emph{list}) \tab The first element of the list is a boolean describing if this setting is used. The second element of the list is the value maximum number of points to use for the lambda_Z estimation when "\emph{lambdaRule}" = "R2" or "adjustedR2". By default, the boolean equals \strong{FALSE} and the value is \strong{inf}.\cr\cr
#' "startTimeNotBefore" \tab (\emph{list}) \tab The first element of the list is a boolean describing if this setting is used. The second element of the list is the value minimum time value to use for the lambda_Z estimation when "\emph{lambdaRule}" = "R2" or "adjustedR2". By default, the boolean equals \strong{FALSE} and the value is \strong{0}.\cr\cr
#' "weightingNca" \tab (\emph{string}) \tab Weighting method used for the regression that estimates lambda_Z. Possible methods are "Y", "Y2" or "\strong{uniform}" (default).\cr\cr
#' }
#' @param ... A collection of comma-separated pairs \{settingName = settingValue\}.
#' @examples
#' \dontrun{
#' setNCASettings(integralMethod = "LinLogTrapLinLogInterp", weightingnca = "uniform") # set the settings whose name has been passed in argument
#' setNCASettings(administrationType = list("1"="extravascular")) # set the administration id "1" to extravascular
#' setNCASettings(startTimeNotBefore = list(TRUE, 15)) # set the estimation of the lambda_z with points with time over 15
#' setNCASettings(timeValuesPerId = list('1'=c(4, 6, 8, 30), '4'=c(8, 12, 18, 24, 30))) # set the points to use for the lambda_z to time={4, 6, 8, 30} for id '1' and ime={8, 12, 18, 24, 30} for id '4' 
#' setNCASettings(timeValuesPerId = NULL) # set the points to use for the lambda_z to the default rule
#' }
#' @seealso \code{\link{getNCASettings}}
#' @export
setNCASettings <-function(...){

  arguments = list(...)
  arguments <-.formatPkanalixSettings(arguments)
  arg <- .formatSetSettingsArguments(arguments)
  settingNames <- arg$settingNames
  arguments <- arg$arguments
  if (!arg$ok) return(invisible())

  if (length(settingNames) > 0){
    for (i in 1:length(settingNames)){
      if (.checkPKanalixSettingType(settingNames[i],arguments[[settingNames[i]]]) == FALSE){
        return(invisible(FALSE))
      }
    }
    output = .processRequest("pkanalix", "setncasettings", arguments, "synchronous", type = "STATUS")
    return(invisible(output))
  }
  else {
    return(invisible(TRUE))
  }

}

#' [PKanalix] Get the data settings associated to the non compartmental analysis
#'
#' Get the data settings associated to the non compartmental analysis. Associated settings are:
#' \tabular{lll}{
#' "urinevolume" \tab (\emph{string}) \tab regressor name used as urine volume.\cr\cr
#' "datatype" \tab (\emph{list}) \tab list("obsId" = \emph{string}("plasma" or "urine"). The type of data associated with each \emph{obsId}: observation ID from data set. \cr
#' }
#' @param ... [optional] (string) Name of the settings whose value should be displayed. If no argument is provided, all the settings are returned.
#' @return An array which associates each setting name to its current value.
#' @examples
#' \dontrun{
#' getDataSettings() # retrieve a list of all the NCA methodology settings
#' getDataSettings("urinevolume") # retrieve a list containing only the value of the settings whose name has been passed in argument
#' }
#' @seealso \code{\link{setNCASettings}}
#' @export
getDataSettings <- function(...){
  
  arguments = list(...)
  if(!.checkGetSettingsArguments(arguments, "settings")) return(invisible())
  
  output = .processRequest("pkanalix", "getdatasettings", arguments, "asynchronous")
  if (!is.null(output))
    output <- as.list(output)
  
  return(output)
  
}

#' [PKanalix] Set the value of one or several of the data settings associated to the non compartmental analysis
#'
#' Set the value of one or several of the data settings associated to the non compartmental analysis. Associated settings names are:
#' \tabular{lll}{
#' "urinevolume" \tab (\emph{string}) \tab regressor name used as urine volume.\cr\cr
#' "datatype" \tab (\emph{list}) \tab list("obsId" = \emph{string}("plasma" or "urine"). The type of data associated with each \emph{obsId}. Default \strong{"plasma"}.\cr
#' }
#' @param ... A collection of comma-separated pairs \{settingName = settingValue\}.
#' @examples
#' \dontrun{
#' setDataSettings("datatype" = list("Y" ="plasma")) # set the settings whose name has been passed in argument
#' }
#' @seealso \code{\link{getDataSettings}}
#' @export
setDataSettings <-function(...){
  
  arguments = list(...)
  arguments <-.formatPkanalixSettings(arguments)
  arg <- .formatSetSettingsArguments(arguments)
  settingNames <- arg$settingNames
  arguments <- arg$arguments
  if (!arg$ok) return(invisible())
  
  if (length(settingNames) > 0){
    for (i in 1:length(settingNames)){
      if (.checkPKanalixSettingType(settingNames[i],arguments[[settingNames[i]]]) == FALSE){
        return(invisible(FALSE))
      }
    }
    output = .processRequest("pkanalix", "setdatasettings", arguments, "synchronous", type = "STATUS")
    return(invisible(output))
  }
  else {
    return(invisible(TRUE))
  }
  
}

# -------------------------------------------------------------------------------- #

# CA Settings -------------------------------------------------------------------- #
#' [PKanalix] Get the settings associated to the compartmental analysis
#'
#' Get the settings associated to the compartmental analysis. Associated settings are:
#' \tabular{lll}{
#' "weightingCA" \tab (\emph{string}) \tab Type of weighting objective function.\cr\cr
#' "pool" \tab (\emph{logical}) \tab Fit with individual parameters or with the same parameters for all individuals.\cr\cr
#' "initialValues" (\emph{list}) \tab list(param = value, ...): value = initial value of individual parameter param.\cr\cr
#' "blqMethod" \tab (\emph{string}) \tab Method by which the BLQ data should be replaced.\cr
#' }
#' @param ... [optional] (string) Name of the settings whose value should be displayed. If no argument is provided, all the settings are returned.
#' @return An array which associates each setting name to its current value.
#' @examples
#' \dontrun{
#' getCASettings() # retrieve a list of all the CA methodology settings
#' getCASettings("weightingca","blqmethod") # retrieve a list containing only the value of the settings whose name has been passed in argument
#' }
#' @seealso \code{\link{setCASettings}}
#' @export
getCASettings <- function(...){

  arguments = list(...)
  if(!.checkGetSettingsArguments(arguments, "settings")) return(invisible())

  output = .processRequest("pkanalix", "getcasettings", arguments, "asynchronous")
  
  if (!is.null(output))
    output <- as.list(output)

  return(output)

}

#' [PKanalix] Get the settings associated to the compartmental analysis
#'
#' Get the settings associated to the compartmental analysis. Associated settings names are:
#' \tabular{lll}{
#' "weightingCA" \tab (\emph{string}) \tab Type of weighting objective function. Possible methods are "uniform", "Yobs", "Ypred", "Ypred2" or "\strong{Yobs2}" (default).\cr\cr
#' "pool" \tab (\emph{logical}) \tab If TRUE, fit with individual parameters or with the same parameters for all individuals if FALSE.
#' \strong{FALSE} (default).\cr\cr
#' "initialValues" (\emph{list}) \tab list(param = value, ...): value = initial value of individual parameter param.\cr\cr
#' "blqMethod" \tab (\emph{string}) \tab  Method by which the BLQ data should be replaced. Possible methods are "zero", "LOQ", "LOQ2" or "\strong{missing}" (default).\cr
#' }
#' @param ... A collection of comma-separated pairs \{settingName = settingValue\}.
#' @examples
#' \dontrun{
#' setCASettings(weightingCA = "uniform", blqMethod = "zero") # set the settings whose name has been passed in argument
#' setCASettings(initialValues = list(Cl=0.4, V=.5, ka=0.04) # set the paramters CL, V, and ka to .4, .5 and .04 respectively
#' }
#' @seealso \code{\link{getCASettings}}
#' @export
setCASettings <- function(...){

  arguments = list(...)

  arg <- .formatSetSettingsArguments(arguments)
  settingNames <- arg$settingNames;
  arguments <- arg$arguments
  if (!arg$ok) return(invisible())

  if (length(settingNames) > 0){
    for (i in 1:length(settingNames)){
      if (.checkPKanalixSettingType(settingNames[i],arguments[[settingNames[i]]]) == FALSE){
        return(invisible(FALSE))
      }
    }
    output = .processRequest("pkanalix", "setcasettings", arguments, "synchronous", type = "STATUS")
    return(invisible(output))
  }
  else {
    return(invisible(TRUE))
  }

}
# -------------------------------------------------------------------------------- #

.checkPKanalixSettingType = function(settingName, settingValue){

  isValid = TRUE
  settingName = tolower(settingName)

  if (settingName == "weightingca" || settingName == "weightingnca" || settingName == "blqmethod"
      || settingName == "lambdarule"  || settingName == "integralmethod"
      || settingName == "blqmethodbeforetmax" || settingName == "blqmethodaftertmax"
      || settingName == "obsidtouse" || settingName == "urinevolume"
      ){
    if (is.character(settingValue) == FALSE){
      .error(paste0("Unexpected type encountered. \"", settingName, "\" must be a string."))
      isValid = FALSE
    }
  }
  else if (settingName == "administrationtype" || settingName == "datatype"){
    if (is.list(settingValue) == FALSE){
      .error(paste0("Unexpected type encountered. \"", settingName, "\" '", names(settingValue)[i],"' must be a string."))
      isValid = FALSE
    }
  }
  else if (settingName == "pool"){
    if (is.logical(settingValue) == FALSE){
      .error("Unexpected type encountered. \"pool\" must be logical.")
      isValid = FALSE
    }
  }
  else if (settingName == "initialvalues"){
    for(i in 1: length(settingValue))
    if (length(settingValue[[i]]) != 1 && is.double(settingValue[[i]][[1]]) == FALSE){
      .error(paste0("Unexpected type encountered. The initial value of ", names(settingValue[[i]]), "must be a double."))
      isValid = FALSE
    }
  }
  else if (settingName == "timeinterval"){
    if (length(settingValue) != 2 || is.vector(settingValue, mode = "numeric") == FALSE){
      .error("Unexpected type encountered. The time interval must be a vector of double of size 2.")
      isValid = FALSE
    }
  }
  else if (settingName == "timevaluesperid"){
    for(i in 1:length(settingValue)){
      if (length(settingValue[[i]]) != 0  && is.vector(settingValue[[i]], mode = "numeric") == FALSE){
        .error(paste0("Unexpected type encountered. The time values for individual '", names(settingValue)[i],"' must be a vector of double."))
        isValid = FALSE
        break
      }
    }
  }
  else if (settingName == "nbpoints" ){
    if (.isInteger(settingValue) == FALSE){
      .error(paste0("Unexpected type encountered. \"",settingName,"\" must be a strictly positive integer."))
      isValid = FALSE
    }
  }
  else if (settingName == "maxnbofpoints" ){
    if (.notAListOfSize(settingValue, 2)
        || (is.logical(settingValue[[1]]) == FALSE || .isInteger(settingValue[[2]]) == FALSE)){
      .checkFirstSettingBoolean(settingValue, settingName)
      if(.isInteger(settingValue[[2]]) == FALSE)
        .error(paste0("Unexpected type encountered. The second element of maxNbOfPoints must be a strictly positive integer."))
      isValid = FALSE
    }
  }
  else if (settingName == "starttimenotbefore" ){
    if (.notAListOfSize(settingValue, 2)
        || (is.logical(settingValue[[1]]) == FALSE || is.double(settingValue[[2]]) == FALSE)){
      .checkFirstSettingBoolean(settingValue, settingName)
      if(is.double(settingValue[[2]]) == FALSE)
        .error(paste0("Unexpected type encountered. The second element of startTimeNotBefore must be a double."))
      isValid = FALSE
    }
  }
  else if (settingName == "partialauctime" ){
    if (.notAListOfSize(settingValue, 2)
        || (is.logical(settingValue[[1]]) == FALSE ||
            (length(settingValue[[2]]) != 2 || is.vector(settingValue[[2]], mode = "numeric") == FALSE))){
      .checkFirstSettingBoolean(settingValue, settingName)
      if(length(settingValue[[2]]) != 2 || is.vector(settingValue[[2]], mode = "numeric") == FALSE)
        .error(paste0("Unexpected type encountered. The second element of partialAucTime must be a vector of two doubles."))
      isValid = FALSE
    }
  }
  else if (settingName == "ajdr2acceptancecriteria"){
    if (.notAListOfSize(settingValue, 2)
        || (is.logical(settingValue[[1]]) == FALSE || (is.double(settingValue[[2]]) == FALSE || settingValue[[2]] < 0 || settingValue[[2]] > 1))){
      .checkFirstSettingBoolean(settingValue, settingName)
      if(is.double(settingValue[[2]]) == FALSE || settingValue[[2]] < 0 || settingValue[[2]] > 1)
        .error(paste0("Unexpected type encountered. The second element of ajdr2AcceptanceCriteria must be a double in [0, 1]."))
      isValid = FALSE
    }
  }
  else if (settingName == "extrapaucacceptancecriteria"){
    if (.notAListOfSize(settingValue, 2)
        || (is.logical(settingValue[[1]]) == FALSE || (is.double(settingValue[[2]]) == FALSE || settingValue[[2]] < 0 || settingValue[[2]] > 100))){
      .checkFirstSettingBoolean(settingValue, settingName)
      if(is.double(settingValue[[2]]) == FALSE || settingValue[[2]] < 0 || settingValue[[2]] > 100)
        .error(paste0("Unexpected type encountered. The second element of extrapAucAcceptanceCriteria must be a double in [0, 100]."))
      isValid = FALSE
    }
  }
  else if (settingName == "spanacceptancecriteria"){
    if (.notAListOfSize(settingValue, 2)
        || (is.logical(settingValue[[1]]) == FALSE || (is.double(settingValue[[2]]) == FALSE || settingValue[[2]] <= 0 ))){
      .checkFirstSettingBoolean(settingValue, settingName)
      if(is.double(settingValue[[2]]) == FALSE || settingValue[[2]] <= 0 )
        .error(paste0("Unexpected type encountered. The second element of spanAcceptanceCriteria must be a positive double."))
      isValid = FALSE
    }
  }
  else {
    .error(paste0("\"",settingName,"\" is not a valid setting name."))
    isValid = FALSE
  }

  return(invisible(isValid))

}

.checkFirstSettingBoolean <-function (settingValue, settingName)
{
  if(is.logical(settingValue[[1]]) == FALSE)
    .error(paste0("Unexpected type encountered. \"",settingName,"\" ->[[1]] must be a boolean.")) 
}

.notAListOfSize <- function(settingValue, size){

  OK <- !is.list(settingValue)
  if (!OK)
    OK <- OK * (length(settingValue) == size)

  return(as.logical(OK))

}

.formatPkanalixSettings <- function (arguments)
{
  settingNames = names(arguments)
  for(k in 1:length(arguments)) 
  {
    settingName = tolower(settingNames[k])
    if (settingName == "administrationtype" || settingName == "datatype"){
      argTmp <-  list("key"=  names(arguments[[settingNames[k]]])[1], "value" = arguments[[settingNames[k]]][[1]])
      if(length(arguments[[settingNames[k]]]) > 1){
        for(i in 2:length(arguments[[settingNames[k]]])) {
          argTmp <-  list(argTmp, list("key"=  names(arguments[[settingNames[k]]])[i], "value" = arguments[[settingNames[k]]][[i]]))
        }
      }
      if(length(arguments[[settingNames[k]]]) == 1)
        argTmp <-list(argTmp)
      arguments[[settingNames[k]]] <-argTmp
    }
    
    if(settingName == "timevaluesperid"){
      if(length(arguments[[settingNames[k]]]) == 0)
      {
        timeValPerId <- getNCASettings("timevaluesperid")[["timevaluesperid"]]
        if(length(timeValPerId)){
          values <-list()
          values[[names(timeValPerId)[1]]] <- list()
          if(length(timeValPerId) > 1){
            for(i in 2:length(timeValPerId)){
              values[[names(timeValPerId)[i]]] <- list()
            }
          }
          arguments[[settingNames[k]]] <- values
        }
      }
    }
  }
  return (arguments)
}
# ================================================================================ #
