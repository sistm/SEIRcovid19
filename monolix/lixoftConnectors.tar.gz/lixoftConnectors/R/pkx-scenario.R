# ============================== SCENARIO MANAGEMENT ============================= #
# Running Scenario --------------------------------------------------------------- #
#' [PKanalix] Run both non compartmental and compartmental analysis.
#'
#' Run the NCA analysis and the CA analysis if the structural model for the CA calculation is defined.
#' @param wait (\emph{logical}) Should R wait for run completion before giving back the hand to the user. \emph{TRUE} by default.
#' @examples
#' \dontrun{
#' runEstimation()
#' }
#' @export
runEstimation <-function(wait = TRUE){

  if (!.checkWaitArgument(wait))
    return(invisible(FALSE))

  ncaRun = runNCAEstimation(wait)
  arguments <- list()
  model = .processRequest("pkanalix", "getmodel", arguments, "asynchronous")
  if(!is.null(model)&&!identical(model,"")){
  caRun = runCAEstimation(wait)
  output <- list(CA = caRun, NCA = ncaRun)
  }else{
    output <- list(NCA = ncaRun)
  }
  return(invisible(output))

}

#' [PKanalix] Estimate the individual parameters using non compartmental analysis.
#'
#' Estimate the NCA parameters for each individual of the project. 
#' @param wait (\emph{logical}) Should R wait for run completion before giving back the hand to the user. \emph{TRUE} by default.
#' @examples
#' \dontrun{
#' runNCAEstimation()
#' }
#' @export
runNCAEstimation <-function(wait = TRUE){

  if (!.checkWaitArgument(wait))
    return(invisible(FALSE))

  arguments <- list()
  output = .processRequest("pkanalix", "runnca", arguments, "synchronous", wait = wait, type = "STATUS")
  return(invisible(output))

}

#' [PKanalix] Estimate the individual parameters using compartmental analysis.
#'
#' Estimate the CA parameters for each individual of the project.
#' @param wait (\emph{logical}) Should R wait for run completion before giving back the hand to the user. \emph{TRUE} by default.
#' @examples
#' \dontrun{
#' runCAEstimation()
#' }
#' @export
runCAEstimation <-function(wait = TRUE){

  if (!.checkWaitArgument(wait))
    return(invisible(FALSE))

  arguments <- list()
  output = .processRequest("pkanalix", "runca", arguments, "synchronous", wait = wait, type = "STATUS")
  return(invisible(output))

}
# -------------------------------------------------------------------------------- #
# ================================================================================ #
