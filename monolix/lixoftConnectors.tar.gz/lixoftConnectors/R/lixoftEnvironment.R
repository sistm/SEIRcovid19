LixoftEnvironment <- new.env()


# assign lixoft environment variables:
assign("LIXOFT_DIRECTORY", "", envir = LixoftEnvironment)
assign("LIXOFT_CONNECTORS_LIB_NAME", "", envir = LixoftEnvironment)
assign("LIXOFT_CONNECTORS_LIB_PATH", "", envir = LixoftEnvironment)
assign("LIXOFT_SOFTWARE", "", envir = LixoftEnvironment)


# store original environment variables:
OS = .getOS()
if (OS == "Unix") {
  assign("SYSTEM_PATH", Sys.getenv("LD_LIBRARY_PATH"), envir = LixoftEnvironment)
} else if (OS == "Apple") {
  # path is set during installation
} else if (OS == "Windows") {
  assign("SYSTEM_PATH", Sys.getenv("PATH"), envir = LixoftEnvironment)
}
remove(OS)

assign("ORIGINAL_OPTIONS", options(), envir = LixoftEnvironment)
