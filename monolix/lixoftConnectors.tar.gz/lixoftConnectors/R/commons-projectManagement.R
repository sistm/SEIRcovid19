# ============================== PROJECT MANAGEMENT ============================== #
# Load-Save ---------------------------------------------------------------------- #
#' [Monolix - PKanalix] Load project from file
#'
#' Load a project by parsing the mlxtran-formated file whose path has been given as an input.
#' WARNING: R is sensitive between '\' and '/', only '/' can be used
#' @param projectFile (\emph{character}) Path to the project file. Can be absolute or relative to the current working directory.
#' @examples
#' \dontrun{
#' loadProject("/path/to/project/file.mlxtran") for Linux platform
#' loadProject("C:/Users/path/to/project/file.mlxtran") for Windows platform
#' }
#' @seealso \code{\link{saveProject}}
#' @export
loadProject = function(projectFile){

  if (!is.character(projectFile)){
    .error("Unexpected type encountered. Please give a string corresponding to the path to the mlxtran-formated file to be loaded.")
    return(FALSE)
  }
  
  arguments = list( normalizePath(projectFile, mustWork = FALSE) )
  output = .processRequest(.software(), "loadproject", arguments, "synchronous", type = "STATUS")
  return(invisible(output))
  
}

#' [Monolix - PKanalix] Save current project
#'
#' Save the current project as an Mlxtran-formated file.
#' @param projectFile [optional](\emph{character}) Path where to save a copy of the current mlxtran model. Can be absolute or relative to the current working directory.
#' If no path is given, the file used to build the current configuration is updated.
#' @examples
#' \dontrun{
#' saveProject("/path/to/project/file.mlxtran") # save a copy of the model
#' saveProject() # update current model
#' }
#' @seealso \code{\link{newProject}} \code{\link{loadProject}}
#' @export
saveProject = function(projectFile = ""){
  
  if (!is.character(projectFile)){
    .error("Unexpected type encountered. Please give a string corresponding to the path to the mlxtran-formated file to be used to save the current project.")
    return(invisible(FALSE))
  }
  
  if (projectFile == "")
    output = .processRequest(.software(), "saveproject", "", "synchronous", type = "STATUS")
  else
    output = .processRequest(.software(), "saveasproject", projectFile, "synchronous", type = "STATUS")
  
  return(invisible(output))
  
}

#' [Monolix - PKanalix] Create new project
#'
#' Create a new empty project providing model and data specification. The data specification is:
#' \describe{
#' \item{ Monolix, PKanalix}{
#'    \itemize{
#'    \item dataFile (\emph{string}): path to the data file
#'    \item headerTypes (\emph{array<character>}): vector of headers
#'	  \item observationTypes [optional] (\emph{list}): a list, indexed by observation name, giving the type of each observation present in the data file. If omitted, all the observations will be considered as "continuous"
#'	  \item nbSSDoses (\emph{int}): number of steady-state doses (if there is a SS column)
#'	  \item mapping [optional](\emph{list}): a list giving the observation name associated to each y-type present in the data file
#'	                                         (this field is mandatory when there is a column tagged with the "obsid" headerType)
#'} Please refer to \code{\link{setData}} documentation for a comprehensive description of the "data" argument structure.
#'}
#'\item{ Monolix only}{
#' \itemize{
#'    \item projectFile (\emph{string}): path to the datxplore or pkanalix project file defining the data
#'}
#'}
#'}
#' @param modelFile (\emph{character}) Path to the model file. Can be absolute or relative to the current working directory.
#' @param data (\emph{list}) Structure describing the data.
#' @examples
#' \dontrun{
#' newProject(data = list(dataFile = "/path/to/data/file.txt", 
#'                        headerTypes = c("IGNORE", "OBSERVATION"), 
#'                        observationTypes = list(concentration = "continuous")),
#'            modelFile = "/path/to/model/file.txt")
#'            
#' newProject(data = list(dataFile = "/path/to/data/file.txt", 
#'                        headerTypes = c("IGNORE", "OBSERVATION", "OBSID"), 
#'                        observationTypes = list(concentration = "continuous", effect = "discrete"),
#'                        mapping = list("1" = "concentration", "2" = "effect")),
#'            modelFile = "/path/to/model/file.txt")
#'            
#'                                    
#'            
#' [Monolix only]
#' 
#'   newProject(data = list(projectFile = "/path/to/project/file.datxplore"),
#'              modelFile = "/path/to/model/file.txt")
#' }
#' @seealso \code{\link{newProject}} \code{\link{saveProject}}
#' @import tools
#' @export
newProject = function(modelFile = NULL, data){

  if (.software() == "monolix" && !is.character(modelFile)){
    .error("Unexpected type encountered for the field \"modelFile\". Please give a string corresponding to the path to a model file.")
    return(invisible(FALSE))
  }
  
  if(.software() == "monolix" && is.list(data) & !is.null(data$projectFile)){
    if (is.character(data$projectFile) == FALSE){
      .error("Unexpected type encountered for the field \"projectFile\" from \"data\". Please give a string corresponding to the path to a pkanalix or datxplore project file.")
      return(invisible(FALSE))
    }
    extension = tools::file_ext(data$projectFile)
    if( !(identical(extension,"pkx")) && !(identical(extension, "datxplore"))){
      .error("Unexpected file type encountered for the field \"projectFile\" from \"data\". Please give a string corresponding to the path to a pkanalix or datxplore project file.")
      return(invisible(FALSE)) 
    }
    data$projectFile <- normalizePath(data$projectFile, mustWork = FALSE)
  }
  else{
    if (is.null(data$observationTypes))
      data$observationTypes <- list()
      
    if ( !is.list(data) || is.null(data$dataFile) || is.null(data$headerTypes) || is.null(data$observationTypes) ){
      message = "Unexpected type encountered for the field \"data\". Please give a list containing"
      if(.software() == "monolix"){
        message =paste0(message," the project file for the data, or")
      }
      .error(paste0(message, " at least the data file, the header types and the observation types."))
      return(invisible(FALSE))
    }
    
    if (is.character(data$dataFile) == FALSE){
      .error("Unexpected type encountered for the field \"dataFile\" from \"data\". Please give a string corresponding to the path to a data file.")
      return(invisible(FALSE))
    }
    
    data$dataFile <- normalizePath(data$dataFile, mustWork = FALSE)
  }

  if (!is.null(modelFile) && !(substr(modelFile, 1, 4) == "lib:"))
    modelFile <- normalizePath(modelFile, mustWork = FALSE)

  arguments = list(modelFile, data)
  output = .processRequest(.software(), "createproject", arguments, "synchronous", type = "STATUS")
  return(invisible(output))

}
# -------------------------------------------------------------------------------- #

# Model -------------------------------------------------------------------------- #
#' [Monolix - PKanalix] Set structural model file
#'
#' Set the structural model.
#' NOTE: In case of PKanalix, the user can only use a structural model from the library for the CA analysis. Thus, the structura model should be written 'lib:modelFromLibrary.txt'.\cr
#' @param modelFile (\emph{character}) Path to the model file. Can be absolute or relative to the current working directory.
#' @examples
#' \dontrun{
#' setStructuralModel("/path/to/model/file.txt") # for Monolix
#' setStructuralModel("'lib:oral1_2cpt_kaClV1QV2.txt'") # for PKanalix
#' }
#' @seealso \code{\link{getStructuralModel}}
#' @export
setStructuralModel = function(modelFile){

  if (is.character(modelFile) == FALSE){
    .error("Unexpected type encountered. Please give a string corresponding to the path to a model file.")
    return(invisible(FALSE))
  }
  
  if(.software() == "pkanalix" && !(substr(modelFile, 1, 4) == "lib:") ){
    .error("The model file name must be from mlxtran libraries and start with 'lib:'.")
    return(invisible(FALSE))
  }
  
  if(!(substr(modelFile, 1, 4) == "lib:")){
    modelFile <- normalizePath(modelFile, mustWork = FALSE)
  }
  output = .processRequest(.software(), "setmodel", modelFile, "synchronous", type = "STATUS")
  return(invisible(output))

}

#' [Monolix - PKanalix]Get structural model file
#'
#' Get the model file for the structural model used in the current project.
#' @return A string corresponding to the path to the structural model file.
#' @examples
#' \dontrun{
#' getStructuralModel() => "/path/to/model/inclusion/modelFile.txt"
#' }
#' @seealso \code{\link{setStructuralModel}}
#' @export
getStructuralModel = function(){

  arguments = list()
  output = .processRequest(.software(), "getmodel", arguments, "asynchronous")
  return(output)

}
# -------------------------------------------------------------------------------- #

# Data --------------------------------------------------------------------------- #
.checkData = function(data){
  
  if (is.character(data$dataFile) == FALSE){
    .error("Unexpected type encountered for field \"dataFile\". Please give a string.")
    return(invisible(FALSE))
  }
  
  if (!is.vector(data$headerTypes) && !is.character(data$headerTypes)){
    .error("Unexpected type encountered for field \"headerTypes\". Please give a collection of strings.")
    return(invisible(FALSE))
  }
  
  if (is.vector(data$observationTypes) || is.list(data$observationTypes)){
    yTypes = names(data$observationTypes)
    
    if (is.null(yTypes) && length(yTypes) == 1){
      if (!is.character(data$observationTypes[[1]])){
        .error(paste0("Unexpected type encountered at position ",i,". Please give a string corresponding to the wanted observation type name of the preceding y-type."))
        return(invisible(FALSE))
      }
      data$observationTypes = data$observationTypes[[1]]
    }
    else if (length(data$observationTypes) > 1){
      for (i in 1:length(data$observationTypes)){
        if (yTypes[i] == ""){
          .error(paste0("No y-type name found at position ",i,"."))
          return(invisible(FALSE))
        }
        else if (is.character(data$observationTypes[[yTypes[i]]]) == FALSE){
          .error(paste0("Unexpected type encountered at position ",i,". Please give a string corresponding to the wanted observation type name of the preceding y-type."))
          return(invisible(FALSE))
        }
      }
    }
  }
  else if (!is.character(data$observationTypes) || length(data$observationTypes) != 1){
    .error("Unexpected type encountered for field \"observationTypes\". Please give a list of string indexed by observation model names.")
    return(invisible(FALSE))
  }
  
  if (!is.null(data$nbSSDoses)){
    if (.isInteger(data$nbSSDoses) == FALSE){
      .error("Unexpected type encountered for field \"nbSSDoses\". Please give an integer.")
      return(invisible(FALSE))
    }
  }
  
  return(invisible(TRUE))
  
}

#' Set project data
#'
#' Set project data giving a data file and specifying headers and observations types.
#' @param dataFile (\emph{character}): Path to the data file. Can be absolute or relative to the current working directory.
#' @param headerTypes (\emph{array<character>}): A collection of header types. 
#' The possible header types are: "ignore", "id", "time", "observation", "amount", "contcov", "catcov", "occ", "evid", "mdv", "obsid", "cens", "limit", "regressor","admid", "rate", "tinf", "ss", "ii", "addl", "date"
#' Notice that these are not the types displayed in the interface, these one are shortcuts.
#' @param observationTypes [optional] (\emph{list}): A list giving the type of each observation present in the data file. If there is only one y-type, the corresponding observation name can be omitted.
#' The possible observation types are "continuous", "discrete", and "event".
#' @param nbSSDoses [optional] (\emph{int}): Number of doses (if there is a SS column).
#' @examples
#' \dontrun{
#' setData(dataFile = "/path/to/data/file.txt", 
#'         headerTypes = c("IGNORE", "OBSERVATION"), observationTypes = "continuous")
#' setData(dataFile = "/path/to/data/file.txt", 
#'         headerTypes = c("IGNORE", "OBSERVATION", "YTYPE"), 
#'         observationTypes = list(Concentration = "continuous", Level = "discrete"))
#' }
#' @seealso \code{\link{getData}}
#' @export
setData = function(dataFile, headerTypes, observationTypes, nbSSDoses = NULL){
  
  if (nargs() == 1 && is.list(dataFile)){
    arguments = dataFile
    if (!is.null(arguments$observationNames) && !is.null(arguments$observationTypes) && is.null(names(arguments$observationTypes)) &&
        length(arguments$observationNames) == length(arguments$observationTypes)){
      names(arguments$observationTypes) <- arguments$observationNames
    }
  }
  else {
    arguments = list(dataFile = dataFile, headerTypes = headerTypes, observationTypes = observationTypes)
    if (!is.null(nbSSDoses))
      arguments$nbSSDoses = nbSSDoses
  }
  
  if (!.checkData(arguments))
    return(invisible(FALSE))
  
  arguments$dataFile <- normalizePath(arguments$dataFile, mustWork = FALSE)
  output = .processRequest(.software(), "setdata", arguments, "synchronous", type = "STATUS")
  return(invisible(output))

}

#' Get project data
#'
#' Get a description of the data used in the current project. Available informations are:
#'    \itemize{
#'    \item dataFile (\emph{string}): path to the data file
#'    \item header (\emph{array<character>}): vector of header names
#'    \item headerTypes (\emph{array<character>}): vector of header types
#'    \item observationNames (\emph{vector<string>}): vector of observation names
#'    \item observationTypes (\emph{vector<string>}): vector of observation types
#'\item nbSSDoses (\emph{int}): number of doses (if there is a SS column)
#'}
#' @return A list describing project data.
#' @examples
#' \dontrun{
#' data = getData()
#' data
#' -> $dataFile
#'      "/path/to/data/file.txt"
#'    $header
#'      c("ID","TIME","CONC","SEX","OCC")
#'    $headerTypes
#'      c("ID","TIME","OBSERVATION","CATEGORICAL COVARIATE","IGNORE")
#'    $observationNames
#'      c("concentration")
#'    $observationTypes
#'      c(concentration = "continuous")
#' }
#' @seealso \code{\link{setData}}
#' @export
getData = function(){

  arguments = list()
  output = .processRequest(.software(), "getdata", arguments, "asynchronous")
  return(output)

}

#' [Monolix] Get observations information
#' 
#' Get the name, the type and the values of the observations present in the project.
#' @return A list containing the name of the observations and their values (id, time and observationName (and occasion if present in the data set))./
#'  In Monolix mode, the observation type and the mapping with data set names is also retrieved.
#' @examples
#' \dontrun{
#' info = getObservationInformation()
#' info
#'   -> $name
#'      c("concentration")
#'   -> $type # [ Monolix ]
#'      c(concentration = "continuous")
#'   -> $mapping # [ Monolix ]
#'      c(concentration = "CONC")
#'   -> $concentration
#'        id   time concentration
#'         1    0.5     0.0
#'         .    .      .
#'         N    9.0    10.8
#' }
#' @export
getObservationInformation = function(){
  
  arguments = list()
  result = .processRequest(.software(), "getobservationsinformation", arguments, "asynchronous")
  output = NaN
  
  if (!is.null(result$value) && length(result$value) > 0){
    output = list(name = result$name)
    if (!is.null(result$mapping))
      output$mapping = result$mapping
    if (!is.null(result$type))
      output$type = result$type
    lvlNames = names(result$ids)
    
    for (iModel in 1:length(result$value)){
      
      resByModel <- result$value[[iModel]]
      
      name = result$name[[iModel]]
      time = c()
      value = c()
      ids = list()
      
      for (iSO in 1:length(resByModel$time)){
        
        if (!length(resByModel$time[[iSO]]))
          next
        
        time = append(time, resByModel$time[[iSO]])
        value = append(value, resByModel$value[[iSO]])
        
        for (iLvl in 1:length(lvlNames))
          ids[[lvlNames[[iLvl]]]] = append( ids[[lvlNames[[iLvl]]]],
                                            rep(result$ids[[lvlNames[[iLvl]]]][[iSO]], length(resByModel$time[[iSO]])) )
      }
      
      output[[name]] = list(time = time)
      output[[name]][[name]] <- value
      output[[name]] = as.data.frame( append(ids, output[[name]]) )
    }
  }
  
  return(output)
  
}

#' Get covariates information
#' 
#' Get the name, the type and the values of the covariates present in the project.
#' @return A list containing the following fields :
#' \itemize{
#' \item name : (\emph{vector<string>}) covariate names
#' \item type : (\emph{vector<string>}) covariate types. Existing types are "continuous", "continuoustransformed", "categorical", "categoricaltransformed"./
#'  In Monolix mode, "latent" covariates are also allowed.
#' \item [Monolix] modalityNumber : (\emph{vector<int>}) number of modalities (for latent covariates only)
#' \item covariate : a data frame giving the values of continuous and categorical covariates for each subject.
#' Latent covariate values exist only if they have been estimated, ie if the covariate is used and if the population parameters have been estimated.
#' Call \code{\link{getEstimatedIndividualParameters}} to retrieve them.
#' }
#' @examples
#' \dontrun{
#' info = getCovariateInformation() # Monolix mode with latent covariates
#' info
#'   -> $name
#'      c("sex","wt","lcat")
#'   -> $type
#'      c(sex = "categorical", wt = "continuous", lcat = "latent")
#'   -> $modalityNumber
#'      c(lcat = 2)
#'   -> $covariate
#'      id   sex    wt
#'       1    M   66.7
#'       .    .      .
#'       N    F   59.0
#' }
#' @export
getCovariateInformation = function(){
  
  arguments = list()
  output = .processRequest(.software(), "getcovariatesinformation", arguments, "asynchronous")
  
  if (!is.null(output) && length(output) > 0){
    if (!is.null(output$covariate) && length(output$covariate) > 0){
      for (i in 1:length(output$covariate)){
        if (length(output$covariate[[i]]) > 0)
          output$covariate[[i]] <- .evalNumerics(output$covariate[[i]])
      }
      output$covariate <- as.data.frame( append(output$ids,output$covariate) )
    }
    else
      output$covariate <- NULL
    
    output$ids <- NULL
  }
  else
    output <- NULL
  
  return(output)
  
}
# -------------------------------------------------------------------------------- #
# ================================================================================ #
