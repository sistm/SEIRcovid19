# ===================================== RESULTS ================================== #
# Helpers ------------------------------------------------------------------------ #
.checkParametersArguments <- function(arguments, paramType){

  return(.checkArguments(arguments, paste0("a list of ", paramType, " parameter")))

}

.checkArguments <- function(arguments, paramStr){

  if (length(arguments) > 0){
    for (i in 1:length(arguments)){
      if (!is.character(arguments[[i]])){
        .error(paste0("Unexpected type encountered at position ",i,". Please give strings corresponding to ",paramStr," names."))
        return(invisible(FALSE))
      }
    }
  }

  return(invisible(TRUE))

}
# -------------------------------------------------------------------------------- #
# ================================================================================ #
